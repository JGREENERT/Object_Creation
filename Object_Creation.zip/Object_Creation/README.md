# object_design_and_transformation
Graphical objects based off digital picture
